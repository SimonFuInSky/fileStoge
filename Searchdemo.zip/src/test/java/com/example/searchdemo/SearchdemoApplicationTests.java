package com.example.searchdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
