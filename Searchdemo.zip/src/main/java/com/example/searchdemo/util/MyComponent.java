package com.example.searchdemo.util;

import com.redis.lettucemod.api.StatefulRedisModulesConnection;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyComponent {

    @Autowired
    StatefulRedisModulesConnection<String, String> connection;

    // ...
}